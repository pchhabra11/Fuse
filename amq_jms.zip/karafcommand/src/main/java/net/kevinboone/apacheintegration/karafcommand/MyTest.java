package net.kevinboone.apacheintegration.karafcommand;
import org.apache.karaf.shell.console.*;
import org.apache.felix.gogo.commands.*;
import javax.management.*;
import javax.management.openmbean.*;
import java.lang.management.*;

@Command(scope="mytest", name="mytest")
public class MyTest extends OsgiCommandSupport
  {
  @Override
  protected Object doExecute() throws Exception 
    {
    System.out.println("Executing test command");
    try
      {
      System.out.println ("Java: " + System.getProperty ("java.vm.name"));
      MBeanServer server = ManagementFactory.getPlatformMBeanServer();
      ObjectName name = new ObjectName("org.apache.activemq:type=Broker,brokerName=amq,destinationType=Queue,destinationName=__test_destination");
      System.out.println ("name=" + name);
      CompositeData[] messages = (CompositeData[]) server.invoke(name, "browse", null, null);
      System.out.println ("messages=" + messages);
      }
    catch (Exception e)
      {
      e.printStackTrace();
      }
    return null;
    }
  }


