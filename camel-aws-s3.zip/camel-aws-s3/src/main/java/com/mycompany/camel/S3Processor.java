package com.mycompany.camel;

import com.amazonaws.SDKGlobalConfiguration;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.aws.s3.S3Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class S3Processor implements Processor {
  
  private AmazonS3Client client;

	private static final Logger LOGGER = LoggerFactory.getLogger(S3Processor.class);
	
	@Override
	public void process(Exchange exchange) throws Exception {
	  System.setProperty(SDKGlobalConfiguration.ENFORCE_S3_SIGV4_SYSTEM_PROPERTY,
	        "true");
	  client.setRegion(Region.getRegion(Regions.EU_WEST_1));
	  // Replace <endpoint> & <bucket_name>
	  //client.setEndpoint("<I commented out this line>");
	  String endpointString = "aws-s3://<BucketName>?amazonS3Client=#client";
	  ProducerTemplate template = exchange.getContext().createProducerTemplate();
      template.sendBodyAndHeader(endpointString, exchange.getIn().getBody(),S3Constants.KEY, "test.csv");

	}

  /**
   * @return the client
   */
  public AmazonS3Client getClient() {
    return client;
  }

  /**
   * @param client the client to set
   */
  public void setClient(AmazonS3Client client) {
    this.client = client;
  } 
   
}
