package com.mycompany.camel;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class MyProcessor implements Processor {

	private static final Logger LOGGER = LoggerFactory.getLogger(MyProcessor.class);
	
	@Override
	public void process(Exchange exchange) throws Exception {
	  List<Map<String, Object>>refData = new ArrayList<Map<String, Object>>();
      Map<String, Object> cntryRefData = null;
      cntryRefData = new LinkedHashMap<String, Object>();
      cntryRefData.put("ID",1);
      cntryRefData.put("CODE","□");
      refData.add(cntryRefData);
      
      cntryRefData = new LinkedHashMap<String, Object>();
      cntryRefData.put("ID",2);
      cntryRefData.put("CODE","是");
      refData.add(cntryRefData);
      LOGGER.info("PRINT 1 !!!!!!!!!!!!!!       "+ (refData.get(0)).get("CODE"));
      LOGGER.info("PRINT 2 ##############       "+ (refData.get(1)).get("CODE"));
      exchange.getIn().setBody(refData);
      LOGGER.info("LOGGER INFO..................."+exchange.getIn().getBody());

	}
    
   
}
