package com.mycompany.camel;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.CsvDataFormat;

public class CamelRoute extends RouteBuilder {
	
	private MyProcessor flProcessor ;
	private S3Processor s3process ;
	
	
	@Override
	public void configure() throws Exception {

		 	CsvDataFormat csvDataFormat = new CsvDataFormat();
		    csvDataFormat.setDelimiter("|");
		    
		    from("timer://hellRouteTimer?period=30s&repeatCount=1").routeId("marshallRoute")
		    .log("triggered")
		    .process(flProcessor)
		    .marshal(csvDataFormat)
		    .log("after marshal ${body}")
		    .process(s3process)
		    .log("after to");
	}


  /**
   * @return the flProcessor
   */
  public MyProcessor getFlProcessor() {
    return flProcessor;
  }


  /**
   * @param flProcessor the flProcessor to set
   */
  public void setFlProcessor(MyProcessor flProcessor) {
    this.flProcessor = flProcessor;
  }


  /**
   * @return the s3process
   */
  public S3Processor getS3process() {
    return s3process;
  }


  /**
   * @param s3process the s3process to set
   */
  public void setS3process(S3Processor s3process) {
    this.s3process = s3process;
  }

}
