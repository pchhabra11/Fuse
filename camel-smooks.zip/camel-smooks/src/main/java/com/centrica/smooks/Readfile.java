package com.centrica.smooks;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Readfile {

	public String readfromfile() throws FileNotFoundException {
		StringBuffer target = new StringBuffer();;
		BufferedReader br = null;
		FileReader fr = null;
		String FILENAME = "/home/pchhabra/Desktop/CasesFolder/01845279/edifact.txt";
		try {

			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);

			String sCurrentLine;

			br = new BufferedReader(new FileReader(FILENAME));

			while ((sCurrentLine = br.readLine()) != null) {
				target.append(sCurrentLine);
			}

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
		return target.toString();
	}
}
