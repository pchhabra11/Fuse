package com.centrica.smooks;

import javax.xml.stream.XMLStreamException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamSource;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;

public class myProcessor implements Processor {
	public void process(Exchange exchange) throws XMLStreamException, TransformerException {

		Message in = exchange.getIn();
		StreamSource source = exchange.getContext().getTypeConverter().tryConvertTo(StreamSource.class, exchange,
				in.getBody());
		if (source != null) {
			in.setBody(source);
			exchange.setIn(in);
		}
	}
}
