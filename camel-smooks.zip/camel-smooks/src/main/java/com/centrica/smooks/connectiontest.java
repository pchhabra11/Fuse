package com.centrica.smooks;

import java.math.BigDecimal;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

public class connectiontest {

	public static void main(String[] args) throws JSONException {
		
		BigDecimal bg=new BigDecimal(20);
		
		JSONObject jo=new JSONObject();
		
		jo.put("test", bg.setScale(3));
		
		System.out.println(jo);
		
	}

}
