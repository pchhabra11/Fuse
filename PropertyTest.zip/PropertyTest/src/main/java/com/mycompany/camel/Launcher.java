package com.mycompany.camel;

import org.apache.camel.CamelContext;
import org.apache.camel.component.properties.PropertiesComponent;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.main.Main;

public class Launcher {
    /**
     * A main() so we can easily run these routing rules in our IDE
     */
    public static void main(String... args) throws Exception {
    	Main main = new Main();
        CamelContext context = new DefaultCamelContext();
    	PropertiesComponent pc = new PropertiesComponent();
    	pc.setLocation("Env.properties");
    	pc.setPropertySuffix(".1");
    	context.addComponent("properties", pc);
    	context.addRoutes(new CamelRoute());
    	context.start();
    	main.run(args);
    	context.stop();
    }
}
